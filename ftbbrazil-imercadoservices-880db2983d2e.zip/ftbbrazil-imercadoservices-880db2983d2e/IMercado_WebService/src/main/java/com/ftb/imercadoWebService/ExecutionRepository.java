package com.ftb.imercadoWebService;

import java.io.Serializable;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ftb.imercado.common.model.*;

@Repository
public interface ExecutionRepository<T, ID extends Serializable> extends MongoRepository<Execution, String>{
}
