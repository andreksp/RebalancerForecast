package com.ftb.transmission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IMercadoTransmissionApplication {

	public static void main(String[] args) {
		SpringApplication.run(IMercadoTransmissionApplication.class, args);
	}
}
