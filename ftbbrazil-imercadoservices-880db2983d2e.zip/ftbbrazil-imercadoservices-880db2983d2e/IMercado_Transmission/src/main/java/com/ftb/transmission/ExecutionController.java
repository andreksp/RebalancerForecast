package com.ftb.transmission;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ftb.imercado.common.model.*;
import com.ftb.imercado.common.util.XmlHelper;

import net.openhft.chronicle.queue.ExcerptAppender;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;

@RestController()
@CrossOrigin(origins = "http://localhost:4200")
public class ExecutionController {

	private final ExecutionRepository<Execution, String> repository;

	@Autowired
	public ExecutionController(ExecutionRepository<Execution, String> repository) {
		this.repository = repository;
	}

	@PostMapping(value = "/imercado/approveExecution")
	@Transactional
	public void save(@RequestBody Execution execution) throws Exception {
		
		//Create Xml to send the response to the sell side.
		String responseXml = this.createResponseMessage(execution);

		//Save in the database.
		repository.save(execution);
		
		SingleChronicleQueue queue = SingleChronicleQueueBuilder.binary("C:\\chronicle\\SellSideReponse").build();
		ExcerptAppender appender = queue.acquireAppender();
		appender.writeText(responseXml);		
	}

	public String createResponseMessage(Execution execution) throws Exception {
		ExecutionResponse executionResponse = new ExecutionResponse();

		// Related Trades
		executionResponse.setRelatedBizMsgIdr(execution.bizMsgIdr);
		executionResponse.setRelatedCreDt(execution.creDt);
		executionResponse.setRelatedMsgDefIdr(execution.msgDefIdr);
		executionResponse.setRelatedIdFrom(execution.IdFrom);
		executionResponse.setRelatedIdTo(execution.IdTo);

		// Header
		executionResponse.setIdFrom(execution.IdTo);
		executionResponse.setIdTo(execution.IdFrom);
		executionResponse.setMsgDefIdr("imb.501.01");

		// Get current date time
		LocalDateTime now = LocalDateTime.now();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

		String formatDateTime = now.format(formatter);

		executionResponse.setBizMsgIdr("FTBIMB50101" + formatDateTime + execution.tradeId);
		executionResponse.setCreDt(LocalDateTime.now());

		executionResponse.setTxId(execution.getTxId()); // New Id know by the participant. Check if can be the same from
														// imb.500
		executionResponse.setExchangePartyTransactionId(execution.getTxId()); // Reference to msg imb.500.
		executionResponse.setSegment(execution.getSegment());

		if (execution.getStatus() == StatusExecution.Approved) {
			executionResponse.setAffirmation("AFFI");
		} else {
			executionResponse.setAffirmation("NAFI");
		}

		GregorianCalendar gcal = (GregorianCalendar) GregorianCalendar.getInstance();
		XMLGregorianCalendar xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
		executionResponse.setStatusDateTime(xgcal.toString());

		org.w3c.dom.Document dom = XmlHelper.loadXMLFromString(executionResponse.xml);
		XmlHelper.updateDomFromObject(dom, executionResponse);
		return XmlHelper.domToString(dom);
	}

}
