package com.ftb.imercado.common.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="executions")
public class ExecutionCancel extends BaseMessage  implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctnCxl/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnCxlSD/Ids/TxId")
	public String txId;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctnCxl/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnCxlSD/TradLegDtlsXtnsn/TradId")
    public int tradeId;
		
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctnCxl/TradLegDtls/AllcnId")
    public String allocationID;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctnCxl/TradLegDtls/TradDt")
    public LocalDateTime tradeDate;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctnCxl/TradLegDtls/BuySellInd")
    public String side;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctnCxl/TradLegDtls/TradQty/Unit")
    public int quantity;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctnCxl/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnCxlSD/FinInstrmAttrbtsInf/TckrSymb")
    public String symbol;
	
	private StatusExecution status = StatusExecution.Canceled;

	@Id
	String id;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public StatusExecution getStatus() {
		return status;
	}

	public void setStatus(StatusExecution status) {
		this.status = status;
	}

	public int getTradeId() {
        return tradeId;
    }

    public void setTradeId(int tradeId) {
        this.tradeId = tradeId;
    }

    public String getAllocationID() {
        return allocationID;
    }

    public void setAllocationID(String allocationID) {
        this.allocationID = allocationID;
    }

    public LocalDateTime getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(LocalDateTime tradeDate) {
        this.tradeDate = tradeDate;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }
    
    public String getTxId() {
        return txId;
    }

    public void setTxId(String txId) {
        this.txId = txId;
    }
}
