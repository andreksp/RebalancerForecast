package com.ftb.imercado.common.util;

import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.ftb.imercado.common.model.AllocationStatus;
import com.ftb.imercado.common.model.BaseMessage;
import com.ftb.imercado.common.model.CustomPath;
import com.ftb.imercado.common.model.Execution;
import com.ftb.imercado.common.model.ExecutionCancel;
import com.ftb.imercado.common.model.StatusExecution;

public class XmlHelper {
	
    public static org.w3c.dom.Document loadXMLFromString(String xml) throws Exception
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(xml));
        return builder.parse(is);
    }
    
    public static String domToString(org.w3c.dom.Document dom) throws Exception
    {       
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer trans = tf.newTransformer();
        StringWriter sw = new StringWriter();
        trans.transform(new DOMSource(dom), new StreamResult(sw));
        return sw.toString();        
    }
    	
    public static void updateDomFromObject(org.w3c.dom.Document dom, BaseMessage baseMessage)
			throws XPathExpressionException, IllegalAccessException {

        XPathFactory xpathfactory = XPathFactory.newInstance();
        XPath xpath = xpathfactory.newXPath();           
    	    	
		Class<?> objectClass = baseMessage.getClass();        
    	
        for (java.lang.reflect.Field f: objectClass.getFields()) {
	    	if (f.isAnnotationPresent(CustomPath.class)) {
	    	   CustomPath column = f.getAnnotation(CustomPath.class);
	    	   if (column != null) {
	    		   f.setAccessible(true);   	       
	    		   XPathExpression xPathExpression = xpath.compile(column.path());
	    	        
	    		   Node node = (Node)xPathExpression.evaluate(dom, XPathConstants.NODE);
	    	           
	    		   Class<?> type = f.getType();
	    	   		if(type.equals(LocalDateTime.class)){
	    	   			     
	    	   			LocalDateTime ldt = (LocalDateTime)f.get(baseMessage);
	    	   			
	    	   			ZoneId id = ZoneId.of("UTC");
	    	   		    ZonedDateTime zoned = ZonedDateTime.of(ldt, id);
	    	   		    
	    	   			String output = zoned.toInstant().toString();
	    	   			
	    	   			node.setTextContent(output);
	    	   		}
	    	   		else if (f.get(baseMessage) != null)
	    	        {
		    	        String newValue = f.get(baseMessage).toString();
		    	        node.setTextContent(newValue);
	    	        }
	    	        else
	    	        {
	    	        	node.setTextContent("");
	    	        }	    	        	
	    	    }
	    	}
    	}       
	}
    
    public static BaseMessage buildObjectFromXml(String fileName) throws Exception {
		   	         
    	org.w3c.dom.Document dom = loadXMLFromString(fileName);
    	
        XPathFactory xpathfactory = XPathFactory.newInstance();
        XPath xpath = xpathfactory.newXPath();
        
    	BaseMessage baseMessage = null;
    	
    	XPathExpression xPathExpression = xpath.compile("/PayloadBVMF/AppHdr/MsgDefIdr");
    	Node node = (Node)xPathExpression.evaluate(dom, XPathConstants.NODE);
    	
    	if ( node.getTextContent().equals("imb.500.01"))
    	{
    		Execution execution = new Execution();
    		execution.setStatus(StatusExecution.Pending);
    		baseMessage = execution; 
    	}    	
    	else if ( node.getTextContent().equals("imb.506.01"))
    	{
    		ExecutionCancel executionCancel = new ExecutionCancel();
    		executionCancel.setStatus(StatusExecution.Canceled);
    		baseMessage = executionCancel; 
    	}
    	else if (node.getTextContent().equals("imb.504.01"))
    	{
    		baseMessage = new AllocationStatus();
    	}
    	else
    	{
    		throw new Exception("Message not implemented yet.");
    	}
    	
		Class<?> objectClass = baseMessage.getClass();        
    	
        for (java.lang.reflect.Field f: objectClass.getFields()) {
	    	if (f.isAnnotationPresent(CustomPath.class)) {
	    	   CustomPath column = f.getAnnotation(CustomPath.class);
	    	   if (column != null) {
	    		    f.setAccessible(true);   	       
	    	        xPathExpression = xpath.compile(column.path());
	    	        
	    	        node = (Node)xPathExpression.evaluate(dom, XPathConstants.NODE);
	    	           	     
	    	        Class<?> type = f.getType();
	    	        
                    if(type.equals(int.class)){
                        f.set(baseMessage, Integer.parseInt(node.getTextContent()));  
                    } else if(type.equals(java.math.BigDecimal.class)){
                    	BigDecimal value = new BigDecimal(node.getTextContent());
                        f.set(baseMessage, value);  
                    } else if(type.equals(LocalDate.class)){
                    	LocalDate date = LocalDate.parse(node.getTextContent());
                        f.set(baseMessage, date);  
                    } else if(type.equals(LocalDateTime.class)){
                    	LocalDateTime date = LocalDateTime.parse(node.getTextContent(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                        f.set(baseMessage, date);                          
                    }  else if(type.equals(boolean.class)){                    	
                        f.set(baseMessage, Boolean.parseBoolean(node.getTextContent()));  
                    } else if(type.equals(java.lang.String.class)){
                        f.set(baseMessage, node.getTextContent());  
                    } else if(type.equals(long.class)){
                    	f.set(baseMessage, Long.parseLong(node.getTextContent()));  
                    }
    	   		}
	    	}
    	}
        return baseMessage;
	}

}