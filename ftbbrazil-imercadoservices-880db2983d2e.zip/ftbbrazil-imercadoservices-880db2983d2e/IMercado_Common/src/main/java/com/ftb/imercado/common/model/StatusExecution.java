package com.ftb.imercado.common.model;

import java.io.Serializable;

public enum StatusExecution implements Serializable {
	Pending (1),
	Approved (2),
	Rejected (3),
	Canceled (4);

    private final int code;

    private StatusExecution(int code) {
        this.code = code;
    }
    
    public int getStatusExecution() {
        return this.code;
    }
}
