package com.ftb.imercado.common.model;

import java.time.LocalDate;

public class AllocationStatus extends BaseMessage {
	
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/PgntnInf/Id/PgntnId")
	public String paginationIdentification;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/PgntnInf/Pgntn/PgNb")
	public int pageNumber;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/PgntnInf/Pgntn/LastPgInd")
	public boolean lastPageIndicator;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/Ids/TxId")
	public String txId;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/Refs/Ref/ExctgPtyTxId")
	public String exctgPtyTxId;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/PtyId/PrtryId/Id")
	public String executingPartyTransactionIdentification;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/PtyId/PrtryId/Id")
	public String proprietaryIdentification;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/TradLegDtls/TradDt/Dt")
	public LocalDate tradeDate;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/TradLegDtls/TradId")
	public int tradeID;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/TradLegDtls/Sd")
	public String side;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/FinInstrmAttrbts/TckrSymb")
	public String symbol;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/FinInstrmAttrbts/Sgmt")
	public int segment;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/FinInstrmAttrbts/Mkt")
	public int market;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/AllcnInf/AllcnId")
	public String allocationID;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/AllcnInf/IndvAllcnId")
	public String individualAllocationID;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/AllcnInf/AcctId/Prtry/Id")
	public int accountIdentification;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/AllcnInf/AllctdQty/Unit")
	public int allocationQuantity;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/AllcnInf/AllcnSts/PrtrySts/StsCd")
	public int statusCode;
	
	@CustomPath(path="/PayloadBVMF/Document/SctiesAllcnInstrStsAdvc/AllcnInstrSts/PrtrySts/StsCd")
	public int instructionStatus;

    public String getPaginationIdentification() {
        return paginationIdentification;
    }

    public void setPaginationIdentification(String paginationIdentification) {
        this.paginationIdentification = paginationIdentification;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Boolean getLastPageIndicator() {
        return lastPageIndicator;
    }

    public void setLastPageIndicator(Boolean lastPageIndicator) {
        this.lastPageIndicator = lastPageIndicator;
    }

    public String getExctgPtyTxId() {
        return exctgPtyTxId;
    }

    public void setExctgPtyTxId(String exctgPtyTxId) {
        this.exctgPtyTxId = exctgPtyTxId;
    }

    public String getExecutingPartyTransactionIdentification() {
        return executingPartyTransactionIdentification;
    }

    public void setExecutingPartyTransactionIdentification(String executingPartyTransactionIdentification) {
        this.executingPartyTransactionIdentification = executingPartyTransactionIdentification;
    }

    public String getProprietaryIdentification() {
        return proprietaryIdentification;
    }

    public void setProprietaryIdentification(String proprietaryIdentification) {
        this.proprietaryIdentification = proprietaryIdentification;
    }

    public LocalDate getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(LocalDate tradeDate) {
        this.tradeDate = tradeDate;
    }

    public int getTradeID() {
        return tradeID;
    }

    public void setTradeID(int tradeID) {
        this.tradeID = tradeID;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public int getSegment() {
        return segment;
    }

    public void setSegment(int segment) {
        this.segment = segment;
    }

    public int getMarket() {
        return market;
    }

    public void setMarket(int market) {
        this.market = market;
    }

    public String getAllocationID() {
        return allocationID;
    }

    public void setAllocationID(String allocationID) {
        this.allocationID = allocationID;
    }

    public String getIndividualAllocationID() {
        return individualAllocationID;
    }

    public void setIndividualAllocationID(String individualAllocationID) {
        this.individualAllocationID = individualAllocationID;
    }

    public int getAccountIdentification() {
        return accountIdentification;
    }

    public void setAccountIdentification(int accountIdentification) {
        this.accountIdentification = accountIdentification;
    }

    public int getAllocationQuantity() {
        return allocationQuantity;
    }

    public void setAllocationQuantity(int allocationQuantity) {
        this.allocationQuantity = allocationQuantity;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public int getInstructionStatus() {
        return instructionStatus;
    }

    public void setInstructionStatus(int instructionStatus) {
        this.instructionStatus = instructionStatus;
    }

    public String getTxId() {
        return txId;
    }

    public void setTxId(String txId) {
        this.txId = txId;
    }

}
