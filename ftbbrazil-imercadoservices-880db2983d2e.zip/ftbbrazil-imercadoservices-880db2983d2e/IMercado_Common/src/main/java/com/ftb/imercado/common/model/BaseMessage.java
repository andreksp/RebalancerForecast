package com.ftb.imercado.common.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class BaseMessage {

	@CustomPath(path="/PayloadBVMF/AppHdr/Fr/OrgId/Id/OrgId/Othr/Id")
	public  String IdFrom = "";
	
	@CustomPath(path="/PayloadBVMF/AppHdr/To/OrgId/Id/OrgId/Othr/Id" )
	public String IdTo = ""; 
	
	@CustomPath(path="/PayloadBVMF/AppHdr/BizMsgIdr" )
	public String bizMsgIdr = "";
	
	@CustomPath(path="/PayloadBVMF/AppHdr/MsgDefIdr" )
	public String msgDefIdr = "";
	
	@CustomPath(path="/PayloadBVMF/AppHdr/CreDt" )
    public LocalDateTime creDt;
    
	public String getIdFrom() {
		return IdFrom;
	}

	public void setIdFrom(String idFrom) {
		IdFrom = idFrom;
	}

	public String getIdTo() {
		return IdTo;
	}

	public void setIdTo(String idTo) {
		IdTo = idTo;
	}

    public String getBizMsgIdr() {
        return bizMsgIdr;
    }

    public void setBizMsgIdr(String bizMsgIdr) {
        this.bizMsgIdr = bizMsgIdr;
    }

    public String getMsgDefIdr() {
        return msgDefIdr;
    }

    public void setMsgDefIdr(String msgDefIdr) {
        this.msgDefIdr = msgDefIdr;
    }

    public LocalDateTime getCreDt() {
        return creDt;
    }

    public void setCreDt(LocalDateTime creDt) {
        this.creDt = creDt;
    }
}
