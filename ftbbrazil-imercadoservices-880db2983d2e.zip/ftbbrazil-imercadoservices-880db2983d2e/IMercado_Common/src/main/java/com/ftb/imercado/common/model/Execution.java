package com.ftb.imercado.common.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="executions")
public class Execution extends BaseMessage  implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnSD/Ids/TxId")
	public String txId;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/TradLegDtls/TradId")
    public int tradeId;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/ClrAcct/Id")
    public int clearAccount;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/TradLegDtls/AllcnId")
    public String allocationID;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/TradLegDtls/TradDt")
    public LocalDateTime tradeDate;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/TradLegDtls/BuySellInd")
    public String side;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/TradLegDtls/TradQty/Unit")
    public int quantity;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/TradLegDtls/DealPric/Val/Amt")
    public BigDecimal price;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnSD/FinInstrmAttrbtsInf/TckrSymb")
    public String symbol;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnSD/FinInstrmAttrbtsInf/CurFctr")
    public int currentFactor;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnSD/FinInstrmAttrbtsInf/Sgmt")
    public int segment;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnSD/FinInstrmAttrbtsInf/Mkt")
    public int market;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnSD/TradLegDtlsXtnsn/TradrId")
    public String traderID;
	
	@CustomPath(path="/PayloadBVMF/Document/TradLegNtfctn/SplmtryData/Envlp/Cnts/Document/TradLegNtfctnSD/GvUpInf")
    public boolean giveUpOnCapture; 
    
	private StatusExecution status = StatusExecution.Pending;

	@Id
	String id;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public StatusExecution getStatus() {
		return status;
	}

	public void setStatus(StatusExecution status) {
		this.status = status;
	}

	public int getTradeId() {
        return tradeId;
    }

    public void setTradeId(int tradeId) {
        this.tradeId = tradeId;
    }

    public int getClearAccount() {
        return clearAccount;
    }

    public void setClearAccount(int clearAccount) {
        this.clearAccount = clearAccount;
    }

    public String getAllocationID() {
        return allocationID;
    }

    public void setAllocationID(String allocationID) {
        this.allocationID = allocationID;
    }

    public LocalDateTime getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(LocalDateTime tradeDate) {
        this.tradeDate = tradeDate;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public int getCurrentFactor() {
        return currentFactor;
    }

    public void setCurrentFactor(int currentFactor) {
        this.currentFactor = currentFactor;
    }

    public int getSegment() {
        return segment;
    }

    public void setSegment(int segment) {
        this.segment = segment;
    }

    public int getMarket() {
        return market;
    }

    public void setMarket(int market) {
        this.market = market;
    }

    public String getTraderID() {
        return traderID;
    }

    public void setTraderID(String traderID) {
        this.traderID = traderID;
    }

    public boolean isGiveUpOnCapture() {
        return giveUpOnCapture;
    }

    public void setGiveUpOnCapture(boolean giveUpOnCapture) {
        this.giveUpOnCapture = giveUpOnCapture;
    }
    
    public String getTxId() {
        return txId;
    }

    public void setTxId(String txId) {
        this.txId = txId;
    }
}
