package com.ftb.imercado.common.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class ExecutionResponse extends BaseMessage implements Serializable {

	public String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><PayloadBVMF><AppHdr xmlns=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" 	xsi:schemaLocation=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01 head.001.001.01.xsd\"><BizMsgIdr>00006090201611110000000000000115021</BizMsgIdr><MsgDefIdr>imb.501.01</MsgDefIdr><CreDt>2017-08-09T17:43:24.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>39-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To><Rltd><BizMsgIdr>00003045201611090000000000000018496</BizMsgIdr><MsgDefIdr>imb.500.01</MsgDefIdr><CreDt>2017-08-09T12:28:17.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>39-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To></Rltd></AppHdr><Document xsi:schemaLocation=\"urn:imb.501.01.xsd imb.501.01.xsd\" xmlns=\"urn:imb.501.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><TradNtfctnRspn><Ids><TxId>00003045201611090000000000000018496</TxId></Ids><Refs><Ref><ExctgPtyTxId>00006090201611110000000000000115021</ExctgPtyTxId></Ref></Refs><TradgSctyInf><Sgmt>4</Sgmt></TradgSctyInf><Sts><AffirmSts><Cd>AFFI</Cd></AffirmSts></Sts><StsDt><DtTm>2017-08-09T12:30:47.0Z</DtTm></StsDt></TradNtfctnRspn></Document></PayloadBVMF>";
	

	//Related
	@CustomPath(path="/PayloadBVMF/AppHdr/Rltd/Fr/OrgId/Id/OrgId/Othr/Id")
	public  String relatedIdFrom = "";
	
	@CustomPath(path="/PayloadBVMF/AppHdr/Rltd/To/OrgId/Id/OrgId/Othr/Id" )
	public String relatedIdTo = ""; 
	
	@CustomPath(path="/PayloadBVMF/AppHdr/Rltd/BizMsgIdr" )
	public String relatedBizMsgIdr = "";
	
	@CustomPath(path="/PayloadBVMF/AppHdr/Rltd/MsgDefIdr" )
	public String relatedMsgDefIdr = "";
	
	@CustomPath(path="/PayloadBVMF/AppHdr/Rltd/CreDt" )
    public LocalDateTime relatedCreDt;
	
	
	@CustomPath(path="/PayloadBVMF/Document/TradNtfctnRspn/Ids/TxId" )
	public String txId;
	
	@CustomPath(path="/PayloadBVMF/Document/TradNtfctnRspn/Refs/Ref/ExctgPtyTxId" )
	public String exchangePartyTransactionId;
	
	@CustomPath(path="/PayloadBVMF/Document/TradNtfctnRspn/TradgSctyInf/Sgmt" )
	public int segment;
	
	@CustomPath(path="/PayloadBVMF/Document/TradNtfctnRspn/Sts/AffirmSts/Cd" )
	public String affirmation;
	
	@CustomPath(path="/PayloadBVMF/Document/TradNtfctnRspn/StsDt/DtTm" )
	public String statusDateTime;
	
	public String getRelatedIdFrom() {
		return relatedIdFrom;
	}
	public void setRelatedIdFrom(String relatedIdFrom) {
		this.relatedIdFrom = relatedIdFrom;
	}
	public String getRelatedIdTo() {
		return relatedIdTo;
	}
	public void setRelatedIdTo(String relatedIdTo) {
		this.relatedIdTo = relatedIdTo;
	}
	public String getRelatedBizMsgIdr() {
		return relatedBizMsgIdr;
	}
	public void setRelatedBizMsgIdr(String relatedBizMsgIdr) {
		this.relatedBizMsgIdr = relatedBizMsgIdr;
	}
	public String getRelatedMsgDefIdr() {
		return relatedMsgDefIdr;
	}
	public void setRelatedMsgDefIdr(String relatedMsgDefIdr) {
		this.relatedMsgDefIdr = relatedMsgDefIdr;
	}
	public LocalDateTime getRelatedCreDt() {
		return relatedCreDt;
	}
	public void setRelatedCreDt(LocalDateTime relatedCreDt) {
		this.relatedCreDt = relatedCreDt;
	}

	public String getExchangePartyTransactionId() {
		return exchangePartyTransactionId;
	}
	public void setExchangePartyTransactionId(String exchangePartyTransactionId) {
		this.exchangePartyTransactionId = exchangePartyTransactionId;
	}
	public int getSegment() {
		return segment;
	}
	public void setSegment(int segment) {
		this.segment = segment;
	}
	public String getAffirmation() {
		return affirmation;
	}
	public void setAffirmation(String affirmation) {
		this.affirmation = affirmation;
	}
	public String getStatusDateTime() {
		return statusDateTime;
	}
	public void setStatusDateTime(String statusDateTime) {
		this.statusDateTime = statusDateTime;
	}
    public String getTxId() {
        return txId;
    }

    public void setTxId(String txId) {
        this.txId = txId;
    }
	
}
