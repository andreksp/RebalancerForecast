package com.ftb.repository;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.ftb.imercado.tradeNotification.MongoConfig;
import com.ftb.imercado.common.model.*;

public class ExecutionRepo {
	public static void saveExecution(Execution tradeLegNotification) {

		ApplicationContext ctx = new AnnotationConfigApplicationContext(MongoConfig.class);
		
		MongoOperations mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
		
		mongoOperation.save(tradeLegNotification, "executions");
	}
	
	public static List<Execution> getExecution(String txId) {

		ApplicationContext ctx = new AnnotationConfigApplicationContext(MongoConfig.class);
		
		Query query = new Query();
		query.addCriteria(Criteria.where("txId").is(txId));
		
		MongoOperations mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
		
		return mongoOperation.find(query, Execution.class, "executions");
	}
	
	public static void delete(String txId) {

		ApplicationContext ctx = new AnnotationConfigApplicationContext(MongoConfig.class);
		
		Query query = new Query();
		query.addCriteria(Criteria.where("txId").is(txId));
		
		MongoOperations mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
		
		mongoOperation.remove(query, Execution.class);
	}
}
