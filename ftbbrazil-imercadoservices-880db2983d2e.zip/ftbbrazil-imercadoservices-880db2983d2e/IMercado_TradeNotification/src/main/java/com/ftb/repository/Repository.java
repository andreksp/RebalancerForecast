package com.ftb.repository;

import java.util.List;

import com.ftb.imercado.common.model.AllocationStatus;
import com.ftb.imercado.common.model.BaseMessage;
import com.ftb.imercado.common.model.Execution;
import com.ftb.imercado.common.model.ExecutionCancel;
import com.ftb.imercado.common.model.StatusExecution;

public class Repository {

	public static void save(BaseMessage baseMessage) {
		
		if (baseMessage instanceof Execution)
		{
			ExecutionRepo.saveExecution((Execution)baseMessage);
		}
		else if (baseMessage instanceof ExecutionCancel)
		{
			ExecutionCancel execCancel = (ExecutionCancel)baseMessage;
			List<Execution> existingExecutions = ExecutionRepo.getExecution(execCancel.getTxId());
			
			if (existingExecutions != null)
			{
				Execution existingExecution =  existingExecutions.get(0);
				
				existingExecution.setStatus(StatusExecution.Canceled);
				ExecutionRepo.saveExecution(existingExecution);
			}
			else
				
			{
				ExecutionCancelRepo.saveExecution(execCancel);
			}
		}					
		else if (baseMessage instanceof AllocationStatus)
		{
			
		}
	}
}
