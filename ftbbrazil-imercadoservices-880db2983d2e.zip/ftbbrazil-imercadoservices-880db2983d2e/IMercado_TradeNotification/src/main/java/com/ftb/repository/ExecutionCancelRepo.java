package com.ftb.repository;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;

import com.ftb.imercado.common.model.Execution;
import com.ftb.imercado.common.model.ExecutionCancel;
import com.ftb.imercado.tradeNotification.MongoConfig;

public class ExecutionCancelRepo {
	public static void saveExecution(ExecutionCancel executionCancel) {

		ApplicationContext ctx = new AnnotationConfigApplicationContext(MongoConfig.class);
		
		MongoOperations mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
		
		mongoOperation.save(executionCancel, "executions");
	}
}
