package com.ftb.imercado.tradeNotification;

import java.io.UnsupportedEncodingException;

import javax.xml.stream.XMLStreamException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ftb.imercado.common.model.*;
import com.ftb.imercado.common.util.XmlHelper;
import com.ftb.repository.ExecutionCancelRepo;
import com.ftb.repository.ExecutionRepo;
import com.ftb.repository.Repository;

import net.openhft.chronicle.queue.ExcerptTailer;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueueBuilder;

@SpringBootApplication
public class IMercadoTradeNotificationApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(IMercadoTradeNotificationApplication.class, args);
		
		SingleChronicleQueue queue = SingleChronicleQueueBuilder.binary("C:\\chronicle\\TradesImercado").build();
		ExcerptTailer tailer = queue.createTailer();

		while (true) {

			String message = tailer.readText();

			try {
				
				if (message != null && message.length() > 0 )
				{
					BaseMessage baseMessage = XmlHelper.buildObjectFromXml(message);
	
					Repository.save(baseMessage);
				}
				
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (XMLStreamException e) {
				e.printStackTrace();
			}
		}

	}

}
