package com.ftb.imercado.tradeNotification;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ftb.imercado.common.model.*;
import com.ftb.imercado.common.util.XmlHelper;
import com.ftb.repository.ExecutionRepo;
import com.ftb.repository.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=IMercadoTradeNotificationApplication.class)
public class IMercadoTradeNotificationApplicationTests {
	
	@Test
	public void ReadTradeNotification() throws Exception {

		String fileName = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><PayloadBVMF><AppHdr xmlns=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01 head.001.001.01.xsd\"><BizMsgIdr>00003045201611090000000000000018496</BizMsgIdr><MsgDefIdr>imb.500.01</MsgDefIdr><CreDt>2017-08-09T12:28:17.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>39-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To></AppHdr><Document xsi:schemaLocation=\"urn:imb.500.01.xsd imb.500.01.xsd\" xmlns=\"urn:imb.500.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:n2=\"urn:SUPL.500.01.xsd\"><TradLegNtfctn><ClrMmb><PrtryId><Id>2-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></ClrMmb><ClrAcct><Id>215133</Id><Tp>CLIE</Tp></ClrAcct><TradLegDtls><TradLegId>0</TradLegId><TradId>82145237</TradId><TradExctnId>0</TradExctnId><OrdrId>89578</OrdrId><AllcnId>T-1-1439221014013-3</AllcnId><TradDt>2017-08-09T09:30:47.0Z</TradDt><FinInstrmId><ISIN>BRBMEFICF1V6</ISIN></FinInstrmId><BuySellInd>BUYI</BuySellInd><TradQty><Unit>100</Unit></TradQty><DealPric><Val><Amt Ccy=\"BRL\">10.00</Amt></Val></DealPric><GrssAmt><Amt Ccy=\"BRL\">10000</Amt></GrssAmt><PlcOfTrad><Tp><Cd>EXCH</Cd></Tp></PlcOfTrad><TradTp>LKTR</TradTp><TradgPty><PrtryId><Id>3-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></TradgPty><TradRegnOrgn>BVMF</TradRegnOrgn><TradgCpcty>PRIN</TradgCpcty></TradLegDtls><SttlmDtls><SttlmAmt><Amt Ccy=\"BRL\">0</Amt></SttlmAmt></SttlmDtls><SplmtryData><Envlp><Cnts><Document xsi:schemaLocation=\"urn:SUPL.500.01.xsd SUPL.500.01.xsd\" xmlns=\"urn:SUPL.500.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><TradLegNtfctnSD><Ids><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><TxId>00003045201611090000000000000018496</TxId></Ids><AllcnInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm></AllcnInf><FinInstrmAttrbtsInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><TckrSymb>ICFZ16</TckrSymb><Sgmt>4</Sgmt><Mkt>2</Mkt><CurFctr>1</CurFctr></FinInstrmAttrbtsInf><TradLegDtlsXtnsn><PlcAndNm>//Document/TradLegNtfctn/TradLegDtls</PlcAndNm><TradgSsnId>1</TradgSsnId><PmtTp>0</PmtTp><TradTxTp>0</TradTxTp><TradgSsnSubId>17</TradgSsnSubId><SctyTradgSts>17</SctyTradgSts><TradrId>123456</TradrId></TradLegDtlsXtnsn><GvUpInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><GvUpOnCaptrInd>false</GvUpOnCaptrInd></GvUpInf></TradLegNtfctnSD></Document></Cnts></Envlp></SplmtryData></TradLegNtfctn></Document></PayloadBVMF>";		
			
		Execution tradeLegNotification = (Execution)XmlHelper.buildObjectFromXml(fileName);
		
		assertEquals(tradeLegNotification.getBizMsgIdr(), "00003045201611090000000000000018496");
		assertEquals(tradeLegNotification.getMsgDefIdr(), "imb.500.01");
		assertEquals(tradeLegNotification.getCreDt(),
				LocalDateTime.parse("2017-08-09T12:28:17.0Z", DateTimeFormatter.ISO_OFFSET_DATE_TIME));
		assertEquals(tradeLegNotification.getTxId(), "00003045201611090000000000000018496");
		assertEquals(tradeLegNotification.getTradeId(), 82145237);
		assertEquals(tradeLegNotification.getClearAccount(), 215133);
		assertEquals(tradeLegNotification.getAllocationID(), "T-1-1439221014013-3");
		assertEquals(tradeLegNotification.getTradeDate(), LocalDateTime.parse("2017-08-09T09:30:47.0Z", DateTimeFormatter.ISO_OFFSET_DATE_TIME));
		assertEquals(tradeLegNotification.getSide(), "BUYI");
		assertEquals(tradeLegNotification.getPrice(), new BigDecimal("10.00"));
		assertEquals(tradeLegNotification.getSymbol(), "ICFZ16");
		assertEquals(tradeLegNotification.getCurrentFactor(), 1);
		assertEquals(tradeLegNotification.getSegment(), 4);
		assertEquals(tradeLegNotification.getMarket(), 2);
		assertEquals(tradeLegNotification.getTraderID(), "123456");
		assertEquals(tradeLegNotification.isGiveUpOnCapture(), false);
	}

	@Test
	public void ReadAllocationStatusAdvice() throws Exception {

		String fileName = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><PayloadBVMF><AppHdr xmlns=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01 head.001.001.01.xsd\"><BizMsgIdr>00003045201611170000000000000020125</BizMsgIdr><MsgDefIdr>imb.504.01</MsgDefIdr><CreDt>2017-08-09T15:57:30.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>39-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To><Rltd><BizMsgIdr>00006090201611170000000000000195530</BizMsgIdr><MsgDefIdr>imb.502.01</MsgDefIdr><CreDt>2017-08-09T15:55:31.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>39-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To></Rltd></AppHdr><Document xsi:schemaLocation=\"urn:imb.504.01.xsd imb.504.01.xsd\" xmlns=\"urn:imb.504.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SctiesAllcnInstrStsAdvc><PgntnInf><Id><PgntnId>ABCDE</PgntnId></Id><Pgntn><PgNb>1</PgNb><LastPgInd>true</LastPgInd></Pgntn></PgntnInf><Ids><TxId>00003045201611170000000000000020125</TxId></Ids><Refs><Ref><ExctgPtyTxId>00006090201611170000000000000195530</ExctgPtyTxId></Ref></Refs><PtyId><PrtryId><Id>3-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></PtyId><TradLegDtls><TradDt><Dt>2017-08-09</Dt></TradDt><TradId>82145237</TradId><Sd>BUYI</Sd></TradLegDtls><FinInstrmAttrbts><TckrSymb>LAME3</TckrSymb><Sgmt>1</Sgmt><Mkt>10</Mkt></FinInstrmAttrbts><AllcnInf><AllcnId>T-1-3589221018888-3</AllcnId><IndvAllcnId>11533264</IndvAllcnId><AcctId><Prtry><Id>15153</Id></Prtry></AcctId><AllctdQty><Unit>100</Unit></AllctdQty><AllcnSts><PrtrySts><StsCd>1</StsCd></PrtrySts></AllcnSts></AllcnInf><AllcnInstrSts><PrtrySts><StsCd>1</StsCd></PrtrySts></AllcnInstrSts></SctiesAllcnInstrStsAdvc></Document></PayloadBVMF>";
		AllocationStatus allocationStatusAdvice = (AllocationStatus)XmlHelper.buildObjectFromXml(fileName);		 
		assertEquals(allocationStatusAdvice.getBizMsgIdr(), "00003045201611170000000000000020125");
		assertEquals(allocationStatusAdvice.getMsgDefIdr(), "imb.504.01");
		assertEquals(allocationStatusAdvice.getCreDt(),
				LocalDateTime.parse("2017-08-09T15:57:30.0Z", DateTimeFormatter.ISO_OFFSET_DATE_TIME));
		assertEquals(allocationStatusAdvice.getPaginationIdentification(), "ABCDE");
		assertEquals(allocationStatusAdvice.getPageNumber(), 1);
		assertEquals(allocationStatusAdvice.getLastPageIndicator(), true);
		assertEquals(allocationStatusAdvice.getTxId(), "00003045201611170000000000000020125");
		assertEquals(allocationStatusAdvice.getTradeDate(), LocalDate.parse("2017-08-09"));
		assertEquals(allocationStatusAdvice.getTradeID(), 82145237);
		assertEquals(allocationStatusAdvice.getSide(), "BUYI");
		assertEquals(allocationStatusAdvice.getSymbol(), "LAME3");
		assertEquals(allocationStatusAdvice.getSegment(), 1);
		assertEquals(allocationStatusAdvice.getMarket(), 10);
		assertEquals(allocationStatusAdvice.getAllocationID(), "T-1-3589221018888-3");
		assertEquals(allocationStatusAdvice.getIndividualAllocationID(), "11533264");
		assertEquals(allocationStatusAdvice.getAccountIdentification(), 15153);
		assertEquals(allocationStatusAdvice.getAllocationQuantity(), 100);
		assertEquals(allocationStatusAdvice.getStatusCode(), 1);
		assertEquals(allocationStatusAdvice.getInstructionStatus(), 1);
	}

	@Test
	public void ReadTradeCancel() throws Exception {

		String fileName = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><PayloadBVMF><AppHdr xmlns=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01 head.001.001.01.xsd\"><BizMsgIdr>00003045201612140000000000000023564</BizMsgIdr><MsgDefIdr>imb.506.01</MsgDefIdr><CreDt>2016-12-14T11:39:38.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>39-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To></AppHdr><Document xsi:schemaLocation=\"urn:imb.506.01.xsd imb.506.01.xsd\" xmlns=\"urn:imb.506.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:n2=\"urn:SUPL.506.01.xsd\"><TradLegNtfctnCxl><ClrMmb><PrtryId><Id>2-1099</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></ClrMmb><ClrAcct><Id>NoFilled</Id><Tp>CLIE</Tp></ClrAcct><TradLegDtls><AllcnId>T-1-1516221013029-8</AllcnId><TradDt>2017-08-09T09:30:47.0Z</TradDt><SttlmDt><Dt>1900-01-01</Dt></SttlmDt><FinInstrmId><ISIN>BRVALEACNPA3</ISIN></FinInstrmId><BuySellInd>BUYI</BuySellInd><TradQty><Unit>100</Unit></TradQty><PlcOfTrad><Tp><Cd>EXCH</Cd></Tp></PlcOfTrad><PlcOfListg><Id><MktIdrCd>BVMF</MktIdrCd></Id><Tp><Cd>EXCH</Cd></Tp></PlcOfListg><TradTp>LKTR</TradTp><TradgPty><PrtryId><Id>3-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></TradgPty><TradgCpcty>PRIN</TradgCpcty></TradLegDtls><SttlmDtls><SttlmAmt><Amt Ccy=\"BRL\">10</Amt></SttlmAmt></SttlmDtls><SplmtryData><PlcAndNm>XPATH</PlcAndNm><Envlp><Cnts><Document xsi:schemaLocation=\"urn:SUPL.506.01.xsd SUPL.506.01.xsd\" xmlns=\"urn:SUPL.506.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><TradLegNtfctnCxlSD><Ids><PlcAndNm>//Document/TradLegNtfctnCxl</PlcAndNm><TxId>00003045201612140000000000000023564</TxId></Ids><FinInstrmAttrbtsInf><PlcAndNm>//Document/TradLegNtfctnCxl</PlcAndNm><TckrSymb>VALE5</TckrSymb></FinInstrmAttrbtsInf><TradLegDtlsXtnsn><PlcAndNm>//Document/TradLegNtfctnCxl/TradLegDtls</PlcAndNm><TradId>907084</TradId></TradLegDtlsXtnsn><GvUpOnCaptrInd><PlcAndNm>//Document/TradLegNtfctnCxl</PlcAndNm><GvUpOnCaptrInd>false</GvUpOnCaptrInd></GvUpOnCaptrInd><TradLegInfCxl><PlcAndNm>//Document/TradLegNtfctnCxl</PlcAndNm><TradLegDtlsCxl><TradCxlDtTm>2017-08-09T09:30:47.0Z</TradCxlDtTm><TradRmngQty>0</TradRmngQty></TradLegDtlsCxl></TradLegInfCxl></TradLegNtfctnCxlSD></Document></Cnts></Envlp></SplmtryData></TradLegNtfctnCxl></Document></PayloadBVMF>";		
			
		ExecutionCancel executionCancel = (ExecutionCancel)XmlHelper.buildObjectFromXml(fileName);
		
		assertEquals(executionCancel.getBizMsgIdr(), "00003045201612140000000000000023564");
		assertEquals(executionCancel.getMsgDefIdr(), "imb.506.01");
		assertEquals(executionCancel.getCreDt(),
				LocalDateTime.parse("2016-12-14T11:39:38.0Z", DateTimeFormatter.ISO_OFFSET_DATE_TIME));
		assertEquals(executionCancel.getTxId(), "00003045201612140000000000000023564");
		assertEquals(executionCancel.getTradeId(), 907084);
		assertEquals(executionCancel.getAllocationID(), "T-1-1516221013029-8");
		assertEquals(executionCancel.getTradeDate(), LocalDateTime.parse("2017-08-09T09:30:47.0Z", DateTimeFormatter.ISO_OFFSET_DATE_TIME));
		assertEquals(executionCancel.getSide(), "BUYI");
		assertEquals(executionCancel.getSymbol(), "VALE5");
	}
	
	@Test()
	public void SaveExecution() throws Exception {
		String message = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><PayloadBVMF><AppHdr xmlns=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01 head.001.001.01.xsd\"><BizMsgIdr>00003045201611090000000000000018496</BizMsgIdr><MsgDefIdr>imb.500.01</MsgDefIdr><CreDt>2017-08-09T12:28:17.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>3-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To></AppHdr><Document xsi:schemaLocation=\"urn:imb.500.01.xsd imb.500.01.xsd\" xmlns=\"urn:imb.500.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:n2=\"urn:SUPL.500.01.xsd\"><TradLegNtfctn><ClrMmb><PrtryId><Id>2-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></ClrMmb><ClrAcct><Id>215133</Id><Tp>CLIE</Tp></ClrAcct><TradLegDtls><TradLegId>0</TradLegId><TradId>82145237</TradId><TradExctnId>0</TradExctnId><OrdrId>89578</OrdrId><AllcnId>T-1-1439221014013-3</AllcnId><TradDt>2017-08-09T09:30:47.0Z</TradDt><FinInstrmId><ISIN>BRBMEFICF1V6</ISIN></FinInstrmId><BuySellInd>BUYI</BuySellInd><TradQty><Unit>100</Unit></TradQty><DealPric><Val><Amt Ccy=\"BRL\">10.00</Amt></Val></DealPric><GrssAmt><Amt Ccy=\"BRL\">10000</Amt></GrssAmt><PlcOfTrad><Tp><Cd>EXCH</Cd></Tp></PlcOfTrad><TradTp>LKTR</TradTp><TradgPty><PrtryId><Id>3-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></TradgPty><TradRegnOrgn>BVMF</TradRegnOrgn><TradgCpcty>PRIN</TradgCpcty></TradLegDtls><SttlmDtls><SttlmAmt><Amt Ccy=\"BRL\">0</Amt></SttlmAmt></SttlmDtls><SplmtryData><Envlp><Cnts><Document xsi:schemaLocation=\"urn:SUPL.500.01.xsd SUPL.500.01.xsd\" xmlns=\"urn:SUPL.500.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><TradLegNtfctnSD><Ids><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><TxId>00003045201611090000000000000018496</TxId></Ids><AllcnInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm></AllcnInf><FinInstrmAttrbtsInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><TckrSymb>ICFZ16</TckrSymb><Sgmt>4</Sgmt><Mkt>2</Mkt><CurFctr>1</CurFctr></FinInstrmAttrbtsInf><TradLegDtlsXtnsn><PlcAndNm>//Document/TradLegNtfctn/TradLegDtls</PlcAndNm><TradgSsnId>1</TradgSsnId><PmtTp>0</PmtTp><TradTxTp>0</TradTxTp><TradgSsnSubId>17</TradgSsnSubId><SctyTradgSts>17</SctyTradgSts><TradrId>123456</TradrId></TradLegDtlsXtnsn><GvUpInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><GvUpOnCaptrInd>false</GvUpOnCaptrInd></GvUpInf></TradLegNtfctnSD></Document></Cnts></Envlp></SplmtryData></TradLegNtfctn></Document></PayloadBVMF>";

		BaseMessage baseMessage = XmlHelper.buildObjectFromXml(message);

		Repository.save(baseMessage);
	}
	
	@Test()
	public void CancelExecution() throws Exception {
		
		String message = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><PayloadBVMF><AppHdr xmlns=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01 head.001.001.01.xsd\"><BizMsgIdr>00003045201611090000000000000018496</BizMsgIdr><MsgDefIdr>imb.500.01</MsgDefIdr><CreDt>2017-08-09T12:28:17.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>3-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To></AppHdr><Document xsi:schemaLocation=\"urn:imb.500.01.xsd imb.500.01.xsd\" xmlns=\"urn:imb.500.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:n2=\"urn:SUPL.500.01.xsd\"><TradLegNtfctn><ClrMmb><PrtryId><Id>2-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></ClrMmb><ClrAcct><Id>215133</Id><Tp>CLIE</Tp></ClrAcct><TradLegDtls><TradLegId>0</TradLegId><TradId>10</TradId><TradExctnId>0</TradExctnId><OrdrId>89578</OrdrId><AllcnId>T-1-1439221014013-3</AllcnId><TradDt>2017-08-09T09:30:47.0Z</TradDt><FinInstrmId><ISIN>BRBMEFICF1V6</ISIN></FinInstrmId><BuySellInd>BUYI</BuySellInd><TradQty><Unit>100</Unit></TradQty><DealPric><Val><Amt Ccy=\"BRL\">10.00</Amt></Val></DealPric><GrssAmt><Amt Ccy=\"BRL\">10000</Amt></GrssAmt><PlcOfTrad><Tp><Cd>EXCH</Cd></Tp></PlcOfTrad><TradTp>LKTR</TradTp><TradgPty><PrtryId><Id>3-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></TradgPty><TradRegnOrgn>BVMF</TradRegnOrgn><TradgCpcty>PRIN</TradgCpcty></TradLegDtls><SttlmDtls><SttlmAmt><Amt Ccy=\"BRL\">0</Amt></SttlmAmt></SttlmDtls><SplmtryData><Envlp><Cnts><Document xsi:schemaLocation=\"urn:SUPL.500.01.xsd SUPL.500.01.xsd\" xmlns=\"urn:SUPL.500.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><TradLegNtfctnSD><Ids><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><TxId>00003045201611090000000000000018497</TxId></Ids><AllcnInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm></AllcnInf><FinInstrmAttrbtsInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><TckrSymb>VALE5</TckrSymb><Sgmt>4</Sgmt><Mkt>2</Mkt><CurFctr>1</CurFctr></FinInstrmAttrbtsInf><TradLegDtlsXtnsn><PlcAndNm>//Document/TradLegNtfctn/TradLegDtls</PlcAndNm><TradgSsnId>1</TradgSsnId><PmtTp>0</PmtTp><TradTxTp>0</TradTxTp><TradgSsnSubId>17</TradgSsnSubId><SctyTradgSts>17</SctyTradgSts><TradrId>123456</TradrId></TradLegDtlsXtnsn><GvUpInf><PlcAndNm>//Document/TradLegNtfctn</PlcAndNm><GvUpOnCaptrInd>false</GvUpOnCaptrInd></GvUpInf></TradLegNtfctnSD></Document></Cnts></Envlp></SplmtryData></TradLegNtfctn></Document></PayloadBVMF>";

		BaseMessage baseMessage = XmlHelper.buildObjectFromXml(message);

		Repository.save(baseMessage);
		
		message = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><PayloadBVMF><AppHdr xmlns=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.01 head.001.001.01.xsd\"><BizMsgIdr>00003045201611090000000000000018496</BizMsgIdr><MsgDefIdr>imb.506.01</MsgDefIdr><CreDt>2016-12-14T11:39:38.0Z</CreDt><Fr><OrgId><Id><OrgId><Othr><Id>3-3014</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></Fr><To><OrgId><Id><OrgId><Othr><Id>39-6090</Id><SchmeNm><Prtry>47</Prtry></SchmeNm><Issr>56</Issr></Othr></OrgId></Id></OrgId></To></AppHdr><Document xsi:schemaLocation=\"urn:imb.506.01.xsd imb.506.01.xsd\" xmlns=\"urn:imb.506.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:n2=\"urn:SUPL.506.01.xsd\"><TradLegNtfctnCxl><ClrMmb><PrtryId><Id>2-1099</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></ClrMmb><ClrAcct><Id>NoFilled</Id><Tp>CLIE</Tp></ClrAcct><TradLegDtls><AllcnId>T-1-1516221013029-8</AllcnId><TradDt>2017-08-09T09:30:47.0Z</TradDt><SttlmDt><Dt>1900-01-01</Dt></SttlmDt><FinInstrmId><ISIN>BRVALEACNPA3</ISIN></FinInstrmId><BuySellInd>BUYI</BuySellInd><TradQty><Unit>100</Unit></TradQty><PlcOfTrad><Tp><Cd>EXCH</Cd></Tp></PlcOfTrad><PlcOfListg><Id><MktIdrCd>BVMF</MktIdrCd></Id><Tp><Cd>EXCH</Cd></Tp></PlcOfListg><TradTp>LKTR</TradTp><TradgPty><PrtryId><Id>3-3014</Id><Issr>56</Issr><SchmeNm>47</SchmeNm></PrtryId></TradgPty><TradgCpcty>PRIN</TradgCpcty></TradLegDtls><SttlmDtls><SttlmAmt><Amt Ccy=\"BRL\">10</Amt></SttlmAmt></SttlmDtls><SplmtryData><PlcAndNm>XPATH</PlcAndNm><Envlp><Cnts><Document xsi:schemaLocation=\"urn:SUPL.506.01.xsd SUPL.506.01.xsd\" xmlns=\"urn:SUPL.506.01.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><TradLegNtfctnCxlSD><Ids><PlcAndNm>//Document/TradLegNtfctnCxl</PlcAndNm><TxId>00003045201611090000000000000018497</TxId></Ids><FinInstrmAttrbtsInf><PlcAndNm>//Document/TradLegNtfctnCxl</PlcAndNm><TckrSymb>VALE5</TckrSymb></FinInstrmAttrbtsInf><TradLegDtlsXtnsn><PlcAndNm>//Document/TradLegNtfctnCxl/TradLegDtls</PlcAndNm><TradId>10</TradId></TradLegDtlsXtnsn><GvUpOnCaptrInd><PlcAndNm>//Document/TradLegNtfctnCxl</PlcAndNm><GvUpOnCaptrInd>false</GvUpOnCaptrInd></GvUpOnCaptrInd><TradLegInfCxl><PlcAndNm>//Document/TradLegNtfctnCxl</PlcAndNm><TradLegDtlsCxl><TradCxlDtTm>2017-08-09T09:30:47.0Z</TradCxlDtTm><TradRmngQty>0</TradRmngQty></TradLegDtlsCxl></TradLegInfCxl></TradLegNtfctnCxlSD></Document></Cnts></Envlp></SplmtryData></TradLegNtfctnCxl></Document></PayloadBVMF>";		

		baseMessage = XmlHelper.buildObjectFromXml(message);

		Repository.save(baseMessage);
		
		ExecutionRepo.delete(((ExecutionCancel)baseMessage).getTxId());
	}
}
