package com.ftb.autoApprove;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IMercadoAutoApproveApplication {

	public static void main(String[] args) {
		SpringApplication.run(IMercadoAutoApproveApplication.class, args);
	}
}
